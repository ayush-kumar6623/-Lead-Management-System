# Lead Management System

DigiCoders Technologies Private Limited - Practical Development Test

## Project Overview
A responsive Lead Management System built with React featuring:
- Login authentication with form validation
- Interactive Dashboard with lead statistics and quick actions
- Leads management table with responsive layout
- Service selection dynamically loaded from JSON file (public/services.json)
- Contact actions: Direct Phone Call (tel:) and Email (mailto:)
- Follow-up tracking system with follow-up modal and history modal
- Local persistence using browser localStorage

## Demo Credentials
- Email: admin@digicoders.com
- Password: admin123

## Setup & Run Instructions
1. Install dependencies:
```
npm install
```

2. Start the development server:
```
npm run dev
```

3. Open the displayed local URL in your browser (usually http://localhost:5173).
